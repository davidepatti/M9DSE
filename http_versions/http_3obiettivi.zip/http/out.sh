#!/bin/sh

    pareto="./pareto.latest"
    rm -rf $pareto
    cat $(ls -t ../*pareto* | head -n1) | sed 's/\(\s.\)e/\1.00e/g; s/\(\s...\)e/\10e/g' > $pareto

    cat $pareto | 
    awk '
        /VGS/{print $2 "\t\t" $3 "\t\t" $4 "\t\t" $5 "\t\t" $6 "\t\t" $7 "\t\t" $8 "\t\t" $9 "\t\t" $10 "\t\t" $11 "\t" $12 "\t" $13 "\t" $14 "\t" $15 "\t" $16 "\t" $17 "\t\t" $18}
        /^[0-9]/{print $0}
    ' > $pareto.txt

    cat $pareto | 
    awk '
        /VGS/{print substr($0, index($0,$2))}
        /^[0-9]/{print $0}
    ' | tr "." "," > $pareto.tsv

    cat $pareto | \
    awk '
        BEGIN {
            i = 0;
            print "{ \"data\": ["
        }
        
        /^[0-9]/ {
            if (i==0) { 
                i=1;
                printf("  ");
            } else {
                printf(" ,");
            }
            print "[\"" $1 "\",\"" $2 "\",\"" $3 "\"]"
        }

        END {
            print "] }"
        }
    ' > data.txt

gen=`echo $(grep "g s" ../M9DSE.log | wc -l) - 1 | bc`
echo Generation  $gen > status.txt
tac ../screenlog.0 | awk '/simulation/{print " (" $4, $5 , "of", $7 ")"; exit}' >> status.txt
